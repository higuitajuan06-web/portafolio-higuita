console.log(Date.now());

const menuBtn = document.getElementById('mobile-menu');
const navLinks = document.getElementById('nav-list');

menuBtn.addEventListener('click', () => {
    // Al hacer clic, quita o pone la clase 'active'
    navLinks.classList.toggle('active');
    
    // Opcional: Pequeña animación al botón
    menuBtn.classList.toggle('is-active');
});