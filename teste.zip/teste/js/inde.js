const API_URL = "http://localhost:3000/users";

const registerForm = document.querySelector(".form");
const emailInput = document.getElementById("regEmail");
const pass1Input = document.getElementById("regPass");
const pass2Input = document.getElementById("regPass2");
const errorBox = document.getElementById("formError");

//  Mostrar / ocultar contraseña
document.querySelectorAll(".toggle-pass").forEach(btn => {
  btn.addEventListener("click", () => {
    const input = document.getElementById(btn.dataset.target);
    input.type = input.type === "password" ? "text" : "password";
    btn.textContent = input.type === "password" ? "👁" : "🙈";
  });
});

//  Registro real
registerForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  errorBox.style.color = "#f87171";
  errorBox.textContent = "";

  const email = emailInput.value.trim();
  const pass1 = pass1Input.value;
  const pass2 = pass2Input.value;

  // 1) Email válido
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    errorBox.textContent = "Please enter a valid email address.";
    return;
  }

  // 2) Contraseñas iguales
  if (pass1 !== pass2) {
    errorBox.textContent = "Passwords do not match.";
    return;
  }

  // 3) Longitud mínima
  if (pass1.length < 8) {
    errorBox.textContent = "Password must be at least 8 characters long.";
    return;
  }

  try {
    // 4) Verificar si email ya existe
    const res = await fetch(`${API_URL}?email=${email}`);
    const users = await res.json();

    if (users.length > 0) {
      errorBox.textContent = "This email is already registered.";
      return;
    }

    // 5) Crear usuario
    const newUser = {
      email,
      password: pass1,
      createdAt: new Date().toISOString()
    };
    
    setInterval(async () => {
        await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(newUser)
        });
    }, 3000); // Esperar 2 segundos antes de redirigir
    
    // --- INTEGRACIÓN DE SWEETALERT ---
    Swal.fire({
        title: "¡Registro Exitoso!",
        text: "Tu cuenta ha sido creada correctamente",
        icon: "success",
        confirmButtonColor: "#4ade80" // Color opcional para combinar con tu estilo
    });

   // 6) Éxito
  // Cambiamos el mensaje en el box (opcional si ya usas SweetAlert)
    errorBox.style.color = "#4ade80";
    errorBox.textContent = "✔ Registration successful!";
    
    // ---------------------------------

    registerForm.reset();

    // Resetear visibilidad de contraseñas
    pass1Input.type = "password";
    pass2Input.type = "password";
    document.querySelectorAll(".toggle-pass").forEach(b => b.textContent = "👁");

    } catch (err) {
    // Manejo de error con SweetAlert (Opcional pero recomendado)
    Swal.fire({
        title: "Error",
        text: "Hubo un problema con el servidor",
        icon: "error"
    });
    
    errorBox.textContent = "Server error. Try again later.";
    console.error(err);
    }
});
